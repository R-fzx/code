#include <algorithm>
#include <bitset>
#include <cmath>
#include <cstdio>
#include <ctime>
#include <deque>
#include <functional>
#include <iomanip>
#include <iostream>
#include <map>
#include <numeric>
#include <queue>
#include <random>
#include <set>
#include <vector>
#ifndef ONLINE_JUDGE
#define debug(...) fprintf(stderr, __VA_ARGS__)
#else
#define debug(...)
#endif
#define RF(s) freopen(s ".in", "r", stdin), freopen(s ".out", "w", stdout)

using namespace std;
using LL = long long;
using Pii = pair<int, int>;
using Pll = pair<LL, LL>;

const int kN = 51;

string n;
LL ans;
int c[10], _c[10];

int main() {
  RF("perm");
  ios_base::sync_with_stdio(0), cin.tie(0), cout.tie(0);
  cin >> n;
  for (char i : n) {
    ++c[i - '0'];
  }
  for (int i = 0; i < n.size(); ++i) {
    int x = n[i] - '0';
    for (int j = 0; j < x; ++j) {
      if (c[j]) {
        long double s = 1;
        for (int k = 0, p = 1; k < 10; ++k) {
          for (_c[k] = c[k] - (k == j); _c[k]; s *= p++, s /= _c[k]--) {
          }
        }
        // cout << s << ' ';
        ans += s;
      }
    }
    // cout << '\n';
    --c[x];
  }
  cout << ans;
  return 0;
}
/*
1 1 1
0---
100-
1020
*/