#include <algorithm>
#include <bitset>
#include <cmath>
#include <cstdio>
#include <ctime>
#include <deque>
#include <functional>
#include <iomanip>
#include <iostream>
#include <map>
#include <numeric>
#include <queue>
#include <random>
#include <set>
#include <vector>
#ifndef ONLINE_JUDGE
#define debug(...) fprintf(stderr, __VA_ARGS__)
#else
#define debug(...)
#endif
#define RF(s) freopen(s".in", "r", stdin), freopen(s".out", "w", stdout)

using namespace std;
using LL = long long;
using Pii = pair<int, int>;
using Pll = pair<LL, LL>;
using Pdd = pair<double, double>;

const int kN = 1e5 + 1;
const double kE = 1e-7;

int n;
LL A, B, C, D, M, ans;
Pll a[kN];

int main() {
  RF("crop");
  ios_base::sync_with_stdio(0), cin.tie(0), cout.tie(0);
  cin >> n >> A >> B >> C >> D >> a[1].first >> a[1].second >> M;
  for (int i = 2; i <= n; ++i) {
    a[i].first = (A * a[i - 1].first + B) % M, a[i].second = (C * a[i - 1].second + D) % M;
  }
  // for (int i = 1; i <= n; ++i) {
  //   cout << a[i].first << ' ' << a[i].second << '\n';
  // }
  for (int i = 1; i <= n; ++i) {
    for (int j = i + 1; j <= n; ++j) {
      for (int k = j + 1; k <= n; ++k) {
        double x1 = a[i].first, y1 = a[i].second, x2 = (a[j].first + a[k].first) / 2.0, y2 = (a[j].second + a[k].second) / 2.0;
        double x3 = a[j].first, y3 = a[j].second, x4 = (a[i].first + a[k].first) / 2.0, y4 = (a[i].second + a[k].second) / 2.0;
        double r1 = (x4 - x3) / (x1 - x2), r2 = (y4 - y3) / (y2 - y1);
        double x = r1 * (x1 * y2 - x2 * y1) / (r1 * (y2 - y1) - (y4 - y3)), y = r2 * (x1 * y2 - x2 * y1) / (r2 * (x1 - x2) - (x3 - x4));
        if ((fabs(LL(x) - x) < kE || fabs(LL(x) + 1 - x) < kE) && (fabs(LL(y) - y) < kE || fabs(LL(y) + 1 - y) < kE)) {
          ++ans;
        }
      }
    }
  }
  cout << ans;
  return 0;
}