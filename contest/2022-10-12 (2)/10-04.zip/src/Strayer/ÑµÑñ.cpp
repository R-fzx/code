#include <cstdio>
#include <cstdlib>

using namespace std ;

int main()
{
	freopen("�楤.in", "r", stdin);
	freopen("�楤.out", "w", stdout);
	printf("0\n");
	return 0;
}
