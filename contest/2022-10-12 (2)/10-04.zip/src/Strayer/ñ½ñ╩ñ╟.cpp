#include <cstdio>
#include <cstdlib>

using namespace std ;

int main()
{
	freopen("���ʤ�.in", "r", stdin);
	freopen("���ʤ�.out", "w", stdout);
	printf("1\n");
	return 0;
}
