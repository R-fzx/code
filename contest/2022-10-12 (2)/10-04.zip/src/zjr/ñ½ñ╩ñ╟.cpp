#include<stdio.h>
int main()
{
    freopen("���ʤ�.out","w",stdout);
    printf("1\n");
    return 0;
}
