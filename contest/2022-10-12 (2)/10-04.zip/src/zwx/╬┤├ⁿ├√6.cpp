#include<stdio.h>
#include<stdlib.h>
#include<math.h>
main()
{
     double a;
     //scanf("%lf",&a);
     //a=(180/M_PI)*a;
     a=2.5*M_PI;
     printf("%lf %lf",sin(a),a);
     system("pause");
}
