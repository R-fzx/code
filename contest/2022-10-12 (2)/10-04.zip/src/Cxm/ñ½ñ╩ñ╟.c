#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#define inf "���ʤ�.in"
#define ouf "���ʤ�.out"

int main ()
{
	freopen ( ouf, "w", stdout );
	printf ( "1\n" );
	return ( 0 );
}
