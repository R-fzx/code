#include<stdlib.h>
#include<stdio.h>
#include<math.h>
#include<string.h>
#include<algorithm>
using namespace std;
int N,M,K;
int main()
{
    int i,j,k,l;
    freopen("���ʤ�.in","r",stdin);
    freopen("���ʤ�.out","w",stdout);
    
    printf("0\n");
    
    
    
    
    return(0);
}
