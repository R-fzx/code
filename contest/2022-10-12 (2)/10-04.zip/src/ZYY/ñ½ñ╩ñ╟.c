#include <stdio.h>
#include <stdlib.h>

int n,m,k;

int main()
{
    freopen("���ʤ�.in","r",stdin);
    freopen("���ʤ�.out","w",stdout);
    
    scanf("%d%d%d",&n,&m,&k);
    
    if (k<=2)
       printf("1\n");
    else
    if (k==3)
       printf("2\n");
    else
    if (k==4)
       printf("5\n");
    else
    if (k==5)
       printf("12\n");
    else
        printf("%d\n",rand()%100+1);  
    
    return 0;
}
